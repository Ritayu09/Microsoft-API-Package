# Travis Build Status
[![Build Status](https://travis-ci.com/swapil-ubc/MSTextAnalyzeR.svg?token=7aMyixSTUxpwRyNYiYXE&branch=master)](https://travis-ci.com/swapil-ubc/MSTextAnalyzeR)

# Text Sentiment Package   

Wrapper for Microsoft Text Analytics API for Sentiment Analysis. The packge processes both batch and individual data row POST request for retrieving sentiment. There are plotting functions in the package to analyze the sentiment score as well.  

Vignettes provides an easy walkthrough of how all the functions can be used:

```
library(TextSentiment)
browseVignettes(TextSentiment)
```


# Contributions Code of Conduct

Please note that the 'TextSentiment' project is released with a
[Contributor Code of Conduct](CODE_OF_CONDUCT.md).
By contributing to this project, you agree to abide by its terms.


