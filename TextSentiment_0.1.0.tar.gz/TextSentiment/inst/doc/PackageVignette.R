## ---- echo = FALSE, message = FALSE-------------------------------------------
knitr::opts_chunk$set(collapse = T)
library(TextSentiment)
library(ggplot2)
library(httr)
library(jsonlite)

## -----------------------------------------------------------------------------
dataset <- read.csv('dataset.csv')
dim(dataset)
# text examples in dataset
head(dataset)

## -----------------------------------------------------------------------------
data_with_sentiment <- get_batch_sentiment(dataset, "bf97f12aadaf43d3aeb180ebcd07edaf", "westcentralus")
head(data_with_sentiment)

## -----------------------------------------------------------------------------
# 'density' parameter in graph type for density distribution plot
sentiment_dist_plot(data_with_sentiment, negative_cutoff = 0.35, positive_start = 0.65, graph_alpha = 0.5, graph_type = 'density')

# 'boxplot' parameter in graph type for generating boxplot for each category
sentiment_dist_plot(data_with_sentiment, negative_cutoff = 0.20, positive_start = 0.70, graph_alpha = 0.75, graph_type = 'boxplot')

