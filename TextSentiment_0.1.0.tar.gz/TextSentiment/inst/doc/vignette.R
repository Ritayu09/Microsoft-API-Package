## -----------------------------------------------------------------------------
library(TextSentiment)
library(httr)
library(jsonlite)
data <- read.csv('test.csv')
data_with_sentiment <- get_batch_sentiment(data, "55f27237f0eb405da8aaafdac3d29ee3", "westcentralus")

## -----------------------------------------------------------------------------
data_to_be_updated = data_with_sentiment[is.na(data_with_sentiment$`Sentiment Score`),]
data_to_be_updated

## -----------------------------------------------------------------------------
failed <- read.csv('Error_Log.csv')
failed

## -----------------------------------------------------------------------------
data_to_be_updated$language <- 'en'
data_to_be_updated.2 = subset(data_to_be_updated, select = -c(`Sentiment Score`) )
write.csv(data_to_be_updated.2,'finalTest.csv', row.names = FALSE)
num = length(data_to_be_updated.2[,1])
data_to_be_updated.2

## -----------------------------------------------------------------------------
IDs = 1:num
key = '55f27237f0eb405da8aaafdac3d29ee3'
data = textAnalysisFunction('finalTest.csv', IDs, key)

## ---- fig.width=8, fig.height=10----------------------------------------------
plotFunction(data)

## -----------------------------------------------------------------------------
df <- read.csv('sentiments.csv')
head(df)

## ---- fig.width=8, fig.height=8-----------------------------------------------
plotFunction(df)
#?textAnalysisFunction

## ---- fig.width=8, fig.height=8-----------------------------------------------
df = read.csv('test_out_incorrect_final.csv')
plotStatusFunction(df)


